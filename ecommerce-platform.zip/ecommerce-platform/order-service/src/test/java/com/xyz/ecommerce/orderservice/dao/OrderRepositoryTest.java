package com.xyz.ecommerce.orderservice.dao;

import com.xyz.ecommerce.orderservice.model.Order;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderRepositoryTest {

    @Mock
    private OrderRepository orderRepository;

    private Order sampleOrder;

    @BeforeEach
    void setUp() {
        sampleOrder = Order.builder()
                .id(1L).userId(10L).productId(5L)
                .quantity(2).totalAmount(new BigDecimal("99.99"))
                .status(Order.OrderStatus.PENDING).build();
    }

    @Test
    void findByUserId_ReturnsOrders() {
        when(orderRepository.findByUserId(10L)).thenReturn(List.of(sampleOrder));
        List<Order> result = orderRepository.findByUserId(10L);
        assertEquals(1, result.size());
        assertEquals(10L, result.get(0).getUserId());
    }

    @Test
    void findByUserId_ReturnsEmpty_WhenNoOrders() {
        when(orderRepository.findByUserId(99L)).thenReturn(List.of());
        assertTrue(orderRepository.findByUserId(99L).isEmpty());
    }

    @Test
    void findByStatus_ReturnsMatchingOrders() {
        when(orderRepository.findByStatus(Order.OrderStatus.PENDING)).thenReturn(List.of(sampleOrder));
        List<Order> result = orderRepository.findByStatus(Order.OrderStatus.PENDING);
        assertEquals(1, result.size());
    }

    @Test
    void save_PersistsOrder() {
        when(orderRepository.save(sampleOrder)).thenReturn(sampleOrder);
        Order saved = orderRepository.save(sampleOrder);
        assertNotNull(saved);
        assertEquals(1L, saved.getId());
    }

    @Test
    void findById_ReturnsOrder() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(sampleOrder));
        Optional<Order> result = orderRepository.findById(1L);
        assertTrue(result.isPresent());
    }
}
