package com.xyz.ecommerce.orderservice.observer;

import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.orderservice.model.Order;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

/**
 * Observer pattern tests - verifies customer is notified on both success and failure.
 */
@ExtendWith(MockitoExtension.class)
class CustomerNotificationObserverTest {

    @Mock
    private AppLogger appLogger;

    @InjectMocks
    private CustomerNotificationObserver observer;

    private Order sampleOrder;

    @BeforeEach
    void setUp() {
        sampleOrder = Order.builder()
                .id(1L).userId(10L).productId(5L)
                .quantity(1).totalAmount(new BigDecimal("49.99"))
                .status(Order.OrderStatus.PAYMENT_SUCCESS).build();
    }

    @Test
    void onPaymentSuccess_NotifiesCustomer_WithoutException() {
        assertDoesNotThrow(() -> observer.onPaymentSuccess(sampleOrder));
        verify(appLogger).info(eq(CustomerNotificationObserver.class), any(String.class), any(), any());
    }

    @Test
    void onPaymentFailure_NotifiesCustomer_WithoutException() {
        assertDoesNotThrow(() -> observer.onPaymentFailure(sampleOrder, "Card declined"));
        verify(appLogger).warn(eq(CustomerNotificationObserver.class), any(String.class), any(), any());
    }

    @Test
    void onPaymentSuccess_LogsCorrectly() {
        observer.onPaymentSuccess(sampleOrder);
        verify(appLogger).info(eq(CustomerNotificationObserver.class),
                any(String.class), eq(1L), eq(new BigDecimal("49.99")));
    }

    @Test
    void onPaymentFailure_LogsCorrectly() {
        observer.onPaymentFailure(sampleOrder, "Insufficient funds");
        verify(appLogger).warn(eq(CustomerNotificationObserver.class),
                any(String.class), eq(1L), eq("Insufficient funds"));
    }
}
