package com.xyz.ecommerce.orderservice.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @Test
    void testOrderBuilder() {
        Order order = Order.builder()
                .id(1L).userId(10L).productId(5L)
                .quantity(2).totalAmount(new BigDecimal("99.99"))
                .cardNumber("4111111111111111")
                .build();

        assertEquals(1L, order.getId());
        assertEquals(10L, order.getUserId());
        assertEquals(2, order.getQuantity());
        assertEquals(new BigDecimal("99.99"), order.getTotalAmount());
        assertEquals(Order.OrderStatus.PENDING, order.getStatus());
        assertNotNull(order.getCreatedAt());
    }

    @Test
    void testOrderDefaultStatus_IsPending() {
        Order order = Order.builder().userId(1L).productId(1L)
                .quantity(1).totalAmount(BigDecimal.TEN).build();
        assertEquals(Order.OrderStatus.PENDING, order.getStatus());
    }

    @Test
    void testOrderSetStatus() {
        Order order = new Order();
        order.setStatus(Order.OrderStatus.PAYMENT_SUCCESS);
        assertEquals(Order.OrderStatus.PAYMENT_SUCCESS, order.getStatus());
    }

    @Test
    void testOrderStatusValues() {
        assertNotNull(Order.OrderStatus.valueOf("PENDING"));
        assertNotNull(Order.OrderStatus.valueOf("PROCESSING"));
        assertNotNull(Order.OrderStatus.valueOf("PAYMENT_SUCCESS"));
        assertNotNull(Order.OrderStatus.valueOf("PAYMENT_FAILED"));
        assertNotNull(Order.OrderStatus.valueOf("SHIPPED"));
        assertNotNull(Order.OrderStatus.valueOf("DELIVERED"));
        assertNotNull(Order.OrderStatus.valueOf("CANCELLED"));
    }
}
