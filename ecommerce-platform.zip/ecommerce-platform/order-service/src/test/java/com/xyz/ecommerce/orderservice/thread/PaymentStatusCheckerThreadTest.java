package com.xyz.ecommerce.orderservice.thread;

import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.orderservice.model.Order;
import com.xyz.ecommerce.orderservice.observer.PaymentObserver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.timeout;

/**
 * Multithreading test - verifies child thread runs and notifies observers.
 */
@ExtendWith(MockitoExtension.class)
class PaymentStatusCheckerThreadTest {

    @Mock
    private PaymentObserver paymentObserver;

    @Mock
    private AppLogger appLogger;

    private Order sampleOrder;

    @BeforeEach
    void setUp() {
        sampleOrder = Order.builder()
                .id(2L).userId(10L).productId(5L)
                .quantity(1).totalAmount(new BigDecimal("99.99"))
                .status(Order.OrderStatus.PAYMENT_SUCCESS).build();
    }

    @Test
    void run_CallsOnPaymentSuccess_WhenPaymentSuccessful() throws InterruptedException {
        PaymentStatusCheckerThread task = new PaymentStatusCheckerThread(
                sampleOrder, List.of(paymentObserver), appLogger, true, null);

        Thread thread = new Thread(task);
        thread.start();
        thread.join(3000); // wait up to 3s for thread to complete

        verify(paymentObserver, timeout(3000)).onPaymentSuccess(sampleOrder);
    }

    @Test
    void run_CallsOnPaymentFailure_WhenPaymentFailed() throws InterruptedException {
        PaymentStatusCheckerThread task = new PaymentStatusCheckerThread(
                sampleOrder, List.of(paymentObserver), appLogger, false, "Card declined");

        Thread thread = new Thread(task);
        thread.start();
        thread.join(3000);

        verify(paymentObserver, timeout(3000)).onPaymentFailure(sampleOrder, "Card declined");
    }

    @Test
    void run_DoesNotThrow_WhenObserverListIsEmpty() {
        PaymentStatusCheckerThread task = new PaymentStatusCheckerThread(
                sampleOrder, List.of(), appLogger, true, null);

        assertDoesNotThrow(() -> {
            Thread thread = new Thread(task);
            thread.start();
            thread.join(3000);
        });
    }
}
