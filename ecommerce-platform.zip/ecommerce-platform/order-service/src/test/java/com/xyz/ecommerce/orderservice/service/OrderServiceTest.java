package com.xyz.ecommerce.orderservice.service;

import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.orderservice.dao.OrderRepository;
import com.xyz.ecommerce.orderservice.model.Order;
import com.xyz.ecommerce.orderservice.observer.PaymentObserver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private AppLogger appLogger;

    @Mock
    private PaymentObserver paymentObserver;

    @InjectMocks
    private OrderService orderService;

    private Order sampleOrder;

    @BeforeEach
    void setUp() {
        sampleOrder = Order.builder()
                .id(2L).userId(10L).productId(5L)
                .quantity(2).totalAmount(new BigDecimal("149.99"))
                .cardNumber("4111111111111111").build();
    }

    @Test
    void processOrder_SavesAndReturnsOrder() throws InterruptedException {
        when(orderRepository.save(any(Order.class))).thenReturn(sampleOrder);

        Order result = orderService.processOrder(sampleOrder);

        assertNotNull(result);
        verify(orderRepository, atLeast(1)).save(any(Order.class));
        // Give child thread time to finish
        Thread.sleep(800);
    }

    @Test
    void getOrderById_ReturnsOrder_WhenFound() {
        when(orderRepository.findById(2L)).thenReturn(Optional.of(sampleOrder));

        Order result = orderService.getOrderById(2L);

        assertNotNull(result);
        assertEquals(2L, result.getId());
    }

    @Test
    void getOrderById_Throws_WhenNotFound() {
        when(orderRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> orderService.getOrderById(99L));
    }

    @Test
    void getOrdersByUserId_ReturnsList() {
        when(orderRepository.findByUserId(10L)).thenReturn(List.of(sampleOrder));

        List<Order> result = orderService.getOrdersByUserId(10L);

        assertEquals(1, result.size());
    }

    @Test
    void updateOrderStatus_UpdatesAndReturns() {
        when(orderRepository.findById(2L)).thenReturn(Optional.of(sampleOrder));
        when(orderRepository.save(any())).thenReturn(sampleOrder);

        Order result = orderService.updateOrderStatus(2L, Order.OrderStatus.SHIPPED);

        assertNotNull(result);
        verify(orderRepository).save(any());
    }

    @Test
    void updateOrderStatus_Throws_WhenNotFound() {
        when(orderRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> orderService.updateOrderStatus(99L, Order.OrderStatus.SHIPPED));
    }

    /** Reflection test: simulatePaymentCheck - even ID = success, odd ID = failure */
    @Test
    void reflectionTest_simulatePaymentCheck_EvenId_ReturnsTrue() throws Exception {
        Method method = OrderService.class.getDeclaredMethod("simulatePaymentCheck", Order.class);
        method.setAccessible(true);

        Order evenOrder = Order.builder().id(2L).userId(1L).productId(1L)
                .quantity(1).totalAmount(BigDecimal.TEN).build();

        boolean result = (boolean) method.invoke(orderService, evenOrder);

        assertTrue(result, "Even ID order should simulate payment success");
    }

    @Test
    void reflectionTest_simulatePaymentCheck_OddId_ReturnsFalse() throws Exception {
        Method method = OrderService.class.getDeclaredMethod("simulatePaymentCheck", Order.class);
        method.setAccessible(true);

        Order oddOrder = Order.builder().id(3L).userId(1L).productId(1L)
                .quantity(1).totalAmount(BigDecimal.TEN).build();

        boolean result = (boolean) method.invoke(orderService, oddOrder);

        assertFalse(result, "Odd ID order should simulate payment failure");
    }
}
