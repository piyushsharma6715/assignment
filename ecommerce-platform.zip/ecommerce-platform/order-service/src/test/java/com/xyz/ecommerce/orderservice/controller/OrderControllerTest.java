package com.xyz.ecommerce.orderservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.orderservice.model.Order;
import com.xyz.ecommerce.orderservice.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OrderController.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private OrderService orderService;

    private Order sampleOrder;

    @BeforeEach
    void setUp() {
        sampleOrder = Order.builder()
                .id(1L).userId(10L).productId(5L)
                .quantity(2).totalAmount(new BigDecimal("99.99"))
                .status(Order.OrderStatus.PAYMENT_SUCCESS).build();
    }

    @Test
    void createOrder_Returns201() throws Exception {
        when(orderService.processOrder(any())).thenReturn(sampleOrder);

        mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleOrder)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value(1));
    }

    @Test
    void getOrderById_Returns200_WhenFound() throws Exception {
        when(orderService.getOrderById(1L)).thenReturn(sampleOrder);

        mockMvc.perform(get("/api/v1/orders/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value(10));
    }

    @Test
    void getOrderById_Returns404_WhenNotFound() throws Exception {
        when(orderService.getOrderById(99L)).thenThrow(new ResourceNotFoundException("Order not found"));

        mockMvc.perform(get("/api/v1/orders/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getOrdersByUser_Returns200() throws Exception {
        when(orderService.getOrdersByUserId(10L)).thenReturn(List.of(sampleOrder));

        mockMvc.perform(get("/api/v1/orders/user/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.length()").value(1));
    }

    @Test
    void updateOrderStatus_Returns200() throws Exception {
        when(orderService.updateOrderStatus(eq(1L), eq(Order.OrderStatus.SHIPPED)))
                .thenReturn(sampleOrder);

        mockMvc.perform(patch("/api/v1/orders/1/status")
                        .param("status", "SHIPPED"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }
}
