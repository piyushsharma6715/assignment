package com.xyz.ecommerce.orderservice.thread;

import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.orderservice.model.Order;
import com.xyz.ecommerce.orderservice.observer.PaymentObserver;

import java.util.List;

/**
 * PaymentStatusCheckerThread - Child thread.
 *
 * Demonstrates Java Multi-threading:
 * - Main thread: processes the order
 * - Child thread (this class): checks payment status and notifies customer
 *
 * The child thread notifies the customer for BOTH successful and unsuccessful payment.
 */
public class PaymentStatusCheckerThread implements Runnable {

    private final Order order;
    private final List<PaymentObserver> observers;
    private final AppLogger appLogger;
    private final boolean paymentSuccessful;
    private final String failureReason;

    public PaymentStatusCheckerThread(Order order, List<PaymentObserver> observers,
                                       AppLogger appLogger, boolean paymentSuccessful,
                                       String failureReason) {
        this.order = order;
        this.observers = observers;
        this.appLogger = appLogger;
        this.paymentSuccessful = paymentSuccessful;
        this.failureReason = failureReason;
    }

    @Override
    public void run() {
        String threadName = Thread.currentThread().getName();
        appLogger.info(PaymentStatusCheckerThread.class,
                "[CHILD THREAD: {}] Starting payment status check for Order ID: {}", threadName, order.getId());

        try {
            // Simulate payment processing time
            Thread.sleep(500);

            appLogger.info(PaymentStatusCheckerThread.class,
                    "[CHILD THREAD: {}] Payment status checked. Success: {}", threadName, paymentSuccessful);

            // Notify all observers (Observer pattern)
            notifyObservers();

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            appLogger.error(PaymentStatusCheckerThread.class,
                    "[CHILD THREAD] Interrupted during payment status check", e);
        }

        appLogger.info(PaymentStatusCheckerThread.class,
                "[CHILD THREAD: {}] Payment status check complete for Order ID: {}", threadName, order.getId());
    }

    private void notifyObservers() {
        for (PaymentObserver observer : observers) {
            if (paymentSuccessful) {
                observer.onPaymentSuccess(order);
            } else {
                observer.onPaymentFailure(order, failureReason);
            }
        }
    }
}
