package com.xyz.ecommerce.orderservice.service;

import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.orderservice.dao.OrderRepository;
import com.xyz.ecommerce.orderservice.model.Order;
import com.xyz.ecommerce.orderservice.observer.PaymentObserver;
import com.xyz.ecommerce.orderservice.thread.PaymentStatusCheckerThread;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Order Service - demonstrates:
 * 1. Multi-threading: Main thread processes order; child thread checks payment and notifies
 * 2. Observer pattern: Customer notified on payment success/failure
 * 3. Transaction management
 * 4. Feign/RestTemplate for inter-service calls
 */
@Service
@RequiredArgsConstructor
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;
    private final List<PaymentObserver> paymentObservers;
    private final AppLogger appLogger;

    /**
     * MAIN THREAD processes the order.
     * CHILD THREAD checks payment status and notifies customer.
     *
     * Multi-threading demonstration as per case study requirement.
     */
    public Order processOrder(Order order) {
        String mainThreadName = Thread.currentThread().getName();
        appLogger.info(OrderService.class,
                "[MAIN THREAD: {}] Processing order for User ID: {}", mainThreadName, order.getUserId());

        // Main thread: save order with PROCESSING status
        order.setStatus(Order.OrderStatus.PROCESSING);
        order.setCreatedAt(LocalDateTime.now());
        Order savedOrder = orderRepository.save(order);

        appLogger.info(OrderService.class,
                "[MAIN THREAD: {}] Order saved with ID: {}. Starting child thread for payment check...",
                mainThreadName, savedOrder.getId());

        // Simulate payment success (in real: call payment service)
        boolean paymentSuccess = simulatePaymentCheck(savedOrder);

        // Update order status based on payment
        savedOrder.setStatus(paymentSuccess ? Order.OrderStatus.PAYMENT_SUCCESS : Order.OrderStatus.PAYMENT_FAILED);
        savedOrder.setUpdatedAt(LocalDateTime.now());
        orderRepository.save(savedOrder);

        // CHILD THREAD: checks payment status and notifies customer
        // Main thread continues and completes; child thread runs concurrently
        Thread childThread = new Thread(
                new PaymentStatusCheckerThread(
                        savedOrder,
                        paymentObservers,
                        appLogger,
                        paymentSuccess,
                        paymentSuccess ? null : "Payment gateway declined"
                ),
                "PaymentStatusChecker-" + savedOrder.getId()
        );
        childThread.setDaemon(false); // Non-daemon: completes even if main thread finishes
        childThread.start();

        appLogger.info(OrderService.class,
                "[MAIN THREAD: {}] Order processing complete. Child thread started for notification.",
                mainThreadName);

        return savedOrder;
    }

    @Transactional(readOnly = true)
    public Order getOrderById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
    }

    @Transactional(readOnly = true)
    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public Order updateOrderStatus(Long orderId, Order.OrderStatus newStatus) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderId));
        order.setStatus(newStatus);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    /**
     * Private method to simulate payment check.
     * In production: calls Payment Service via Feign/RestTemplate.
     */
    private boolean simulatePaymentCheck(Order order) {
        // Simulate: orders with even IDs succeed, odd IDs fail (for demo)
        return order.getId() % 2 == 0;
    }
}
