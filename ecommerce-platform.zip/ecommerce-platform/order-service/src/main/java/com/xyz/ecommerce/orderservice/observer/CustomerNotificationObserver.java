package com.xyz.ecommerce.orderservice.observer;

import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.orderservice.model.Order;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Customer Notification Observer - concrete implementation of PaymentObserver.
 * Notifies customer on both successful and unsuccessful payment.
 * Demonstrates Observer pattern used in microservices.
 */
@Component
@RequiredArgsConstructor
public class CustomerNotificationObserver implements PaymentObserver {

    private final AppLogger appLogger;

    @Override
    public void onPaymentSuccess(Order order) {
        appLogger.info(CustomerNotificationObserver.class,
                "NOTIFICATION [SUCCESS] - Customer notified for Order ID: {}, Amount: {}",
                order.getId(), order.getTotalAmount());
        sendNotification(order.getUserId(),
                "Your order #" + order.getId() + " has been confirmed! Amount charged: $" + order.getTotalAmount());
    }

    @Override
    public void onPaymentFailure(Order order, String reason) {
        appLogger.warn(CustomerNotificationObserver.class,
                "NOTIFICATION [FAILURE] - Customer notified for Order ID: {}, Reason: {}",
                order.getId(), reason);
        sendNotification(order.getUserId(),
                "Payment failed for order #" + order.getId() + ". Reason: " + reason + ". Please try again.");
    }

    /**
     * In production: send email/SMS/push notification.
     * Here we simulate notification.
     */
    private void sendNotification(Long userId, String message) {
        appLogger.info(CustomerNotificationObserver.class,
                "[EMAIL/SMS] To User {}: {}", userId, message);
        // Simulate notification delay
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
