package com.xyz.ecommerce.orderservice.observer;

import com.xyz.ecommerce.orderservice.model.Order;

/**
 * Observer interface for payment events.
 * Demonstrates Observer design pattern.
 */
public interface PaymentObserver {

    void onPaymentSuccess(Order order);

    void onPaymentFailure(Order order, String reason);
}
