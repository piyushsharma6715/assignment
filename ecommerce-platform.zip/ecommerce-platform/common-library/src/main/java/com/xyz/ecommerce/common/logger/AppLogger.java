package com.xyz.ecommerce.common.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Common Logger utility - re-usable logging module.
 * Purpose: demonstrate modularity and re-usability via shared .m2 library.
 */
@Component
public class AppLogger {

    public Logger getLogger(Class<?> clazz) {
        return LoggerFactory.getLogger(clazz);
    }

    public void info(Class<?> clazz, String message) {
        getLogger(clazz).info(message);
    }

    public void info(Class<?> clazz, String message, Object... args) {
        getLogger(clazz).info(message, args);
    }

    public void error(Class<?> clazz, String message, Throwable throwable) {
        getLogger(clazz).error(message, throwable);
    }

    public void error(Class<?> clazz, String message) {
        getLogger(clazz).error(message);
    }

    public void warn(Class<?> clazz, String message) {
        getLogger(clazz).warn(message);
    }

    public void debug(Class<?> clazz, String message) {
        getLogger(clazz).debug(message);
    }
}
