package com.xyz.ecommerce.common.exception;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ExceptionTest {

    @Test
    void resourceNotFoundException_HasCorrectMessage() {
        ResourceNotFoundException ex = new ResourceNotFoundException("User not found");
        assertEquals("User not found", ex.getMessage());
        assertInstanceOf(RuntimeException.class, ex);
    }

    @Test
    void badRequestException_HasCorrectMessage() {
        BadRequestException ex = new BadRequestException("Invalid input");
        assertEquals("Invalid input", ex.getMessage());
        assertInstanceOf(RuntimeException.class, ex);
    }
}
