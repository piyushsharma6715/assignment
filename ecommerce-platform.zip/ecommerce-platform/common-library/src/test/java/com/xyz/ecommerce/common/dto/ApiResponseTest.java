package com.xyz.ecommerce.common.dto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ApiResponseTest {

    @Test
    void success_CreatesCorrectResponse() {
        ApiResponse<String> response = ApiResponse.success("data", "OK");
        assertTrue(response.isSuccess());
        assertEquals("OK", response.getMessage());
        assertEquals("data", response.getData());
        assertEquals(200, response.getStatusCode());
    }

    @Test
    void error_CreatesCorrectResponse() {
        ApiResponse<Void> response = ApiResponse.error("Not found", 404);
        assertFalse(response.isSuccess());
        assertEquals("Not found", response.getMessage());
        assertEquals(404, response.getStatusCode());
        assertNull(response.getData());
    }

    @Test
    void builder_CreatesFullResponse() {
        ApiResponse<Integer> response = ApiResponse.<Integer>builder()
                .success(true).message("Created").data(42).statusCode(201).build();
        assertTrue(response.isSuccess());
        assertEquals(42, response.getData());
    }

    @Test
    void success_WithNullData() {
        ApiResponse<Void> response = ApiResponse.success(null, "Deleted");
        assertTrue(response.isSuccess());
        assertNull(response.getData());
    }
}
