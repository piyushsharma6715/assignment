package com.xyz.ecommerce.cardvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.xyz.ecommerce.cardvalidation", "com.xyz.ecommerce.common"})
public class CardValidationServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CardValidationServiceApplication.class, args);
    }
}
