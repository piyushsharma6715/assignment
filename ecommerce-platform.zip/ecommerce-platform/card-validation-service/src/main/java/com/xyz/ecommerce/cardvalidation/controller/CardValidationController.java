package com.xyz.ecommerce.cardvalidation.controller;

import com.xyz.ecommerce.cardvalidation.model.CardDetail;
import com.xyz.ecommerce.cardvalidation.model.CardValidationDTO;
import com.xyz.ecommerce.cardvalidation.service.CardValidationService;
import com.xyz.ecommerce.common.dto.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Card Validation Controller - single GET call returning card details against a card number.
 */
@RestController
@RequestMapping("/api/v1/cards")
@RequiredArgsConstructor
public class CardValidationController {

    private final CardValidationService cardValidationService;

    @GetMapping("/{cardNumber}")
    public ResponseEntity<ApiResponse<CardValidationDTO>> getCardDetails(@PathVariable String cardNumber) {
        CardValidationDTO dto = cardValidationService.getCardDetailsByCardNumber(cardNumber);
        return ResponseEntity.ok(ApiResponse.success(dto, "Card details retrieved successfully"));
    }

    @PostMapping("/validate/{cardNumber}")
    public ResponseEntity<ApiResponse<CardValidationDTO>> validateCard(@PathVariable String cardNumber) {
        CardValidationDTO dto = cardValidationService.validateCard(cardNumber);
        return ResponseEntity.ok(ApiResponse.success(dto, "Card validation completed"));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<CardValidationDTO>> addCard(@RequestBody CardDetail cardDetail) {
        CardValidationDTO dto = cardValidationService.addCard(cardDetail);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(dto, "Card added successfully"));
    }
}
