package com.xyz.ecommerce.cardvalidation.dao;

import com.xyz.ecommerce.cardvalidation.model.CardDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * CardDetail Repository - DAO pattern.
 */
@Repository
public interface CardDetailRepository extends JpaRepository<CardDetail, Long> {

    Optional<CardDetail> findByCardNumber(String cardNumber);

    Optional<CardDetail> findByUserId(Long userId);
}
