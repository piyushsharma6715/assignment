package com.xyz.ecommerce.cardvalidation.service;

import com.xyz.ecommerce.cardvalidation.dao.CardDetailRepository;
import com.xyz.ecommerce.cardvalidation.model.CardDetail;
import com.xyz.ecommerce.cardvalidation.model.CardValidationDTO;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

/**
 * Card Validation Service - business logic.
 * Uses common-library AppLogger to demonstrate re-usability.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class CardValidationService {

    private final CardDetailRepository cardDetailRepository;
    private final AppLogger appLogger;

    public CardValidationDTO getCardDetailsByCardNumber(String cardNumber) {
        appLogger.info(CardValidationService.class, "Fetching card details for card number ending: {}",
                cardNumber.substring(Math.max(0, cardNumber.length() - 4)));

        CardDetail card = cardDetailRepository.findByCardNumber(cardNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Card not found with number: " + cardNumber));

        return CardValidationDTO.fromEntity(card);
    }

    public CardValidationDTO validateCard(String cardNumber) {
        appLogger.info(CardValidationService.class, "Validating card...");

        CardDetail card = cardDetailRepository.findByCardNumber(cardNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Card not found"));

        boolean isValid = validateLuhn(cardNumber) && !isExpired(card);
        card.setValid(isValid);
        cardDetailRepository.save(card);

        CardValidationDTO result = CardValidationDTO.fromEntity(card);
        result.setValidationMessage(isValid ? "Card is valid and active" : "Card validation failed");
        return result;
    }

    public CardValidationDTO addCard(CardDetail cardDetail) {
        boolean isValid = validateLuhn(cardDetail.getCardNumber());
        cardDetail.setValid(isValid);
        cardDetail.setCardType(detectCardType(cardDetail.getCardNumber()));
        CardDetail saved = cardDetailRepository.save(cardDetail);
        return CardValidationDTO.fromEntity(saved);
    }

    /**
     * Luhn algorithm for card number validation.
     * Private method - demonstrates Java Reflection for testing.
     */
    private boolean validateLuhn(String cardNumber) {
        if (cardNumber == null || cardNumber.isBlank()) return false;
        String digits = cardNumber.replaceAll("\\D", "");
        int sum = 0;
        boolean alternate = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(String.valueOf(digits.charAt(i)));
            if (alternate) {
                n *= 2;
                if (n > 9) n -= 9;
            }
            sum += n;
            alternate = !alternate;
        }
        return (sum % 10 == 0);
    }

    /**
     * Check if card is expired - private method for reflection demo.
     */
    private boolean isExpired(CardDetail card) {
        LocalDate now = LocalDate.now();
        LocalDate expiry = LocalDate.of(card.getExpiryYear(), card.getExpiryMonth(), 1)
                .plusMonths(1).minusDays(1);
        return now.isAfter(expiry);
    }

    /**
     * Detect card type from number prefix - private method for reflection demo.
     */
    private String detectCardType(String cardNumber) {
        if (cardNumber.startsWith("4")) return "VISA";
        if (cardNumber.startsWith("5")) return "MASTERCARD";
        if (cardNumber.startsWith("3")) return "AMEX";
        return "UNKNOWN";
    }
}
