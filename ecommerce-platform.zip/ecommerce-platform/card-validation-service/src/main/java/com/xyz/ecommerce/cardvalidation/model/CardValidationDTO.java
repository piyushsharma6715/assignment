package com.xyz.ecommerce.cardvalidation.model;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CardValidationDTO {
    private Long id;
    private String maskedCardNumber;
    private String cardHolderName;
    private String cardType;
    private boolean valid;
    private String validationMessage;

    public static CardValidationDTO fromEntity(CardDetail card) {
        String masked = maskCardNumber(card.getCardNumber());
        return CardValidationDTO.builder()
                .id(card.getId())
                .maskedCardNumber(masked)
                .cardHolderName(card.getCardHolderName())
                .cardType(card.getCardType())
                .valid(card.isValid())
                .validationMessage(card.isValid() ? "Card is valid" : "Card is invalid")
                .build();
    }

    private static String maskCardNumber(String cardNumber) {
        if (cardNumber == null || cardNumber.length() < 4) return "****";
        return "**** **** **** " + cardNumber.substring(cardNumber.length() - 4);
    }
}
