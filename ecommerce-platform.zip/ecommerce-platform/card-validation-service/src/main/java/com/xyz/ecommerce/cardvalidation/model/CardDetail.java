package com.xyz.ecommerce.cardvalidation.model;

import jakarta.persistence.*;
import lombok.*;

/**
 * CardDetail entity - stores masked card details linked to user.
 */
@Entity
@Table(name = "card_details")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CardDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "card_number", nullable = false, unique = true)
    private String cardNumber;

    @Column(name = "card_holder_name", nullable = false)
    private String cardHolderName;

    @Column(name = "expiry_month", nullable = false)
    private int expiryMonth;

    @Column(name = "expiry_year", nullable = false)
    private int expiryYear;

    @Column(name = "card_type")
    private String cardType; // VISA, MASTERCARD, AMEX

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "valid")
    private boolean valid;
}
