package com.xyz.ecommerce.cardvalidation.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xyz.ecommerce.cardvalidation.model.CardDetail;
import com.xyz.ecommerce.cardvalidation.model.CardValidationDTO;
import com.xyz.ecommerce.cardvalidation.service.CardValidationService;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CardValidationController.class)
class CardValidationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CardValidationService cardValidationService;

    private CardValidationDTO sampleDTO;

    @BeforeEach
    void setUp() {
        sampleDTO = CardValidationDTO.builder()
                .id(1L)
                .maskedCardNumber("**** **** **** 1111")
                .cardHolderName("John Doe")
                .cardType("VISA")
                .valid(true)
                .validationMessage("Card is valid")
                .build();
    }

    @Test
    void getCardDetails_Returns200_WhenFound() throws Exception {
        when(cardValidationService.getCardDetailsByCardNumber("4111111111111111"))
                .thenReturn(sampleDTO);

        mockMvc.perform(get("/api/v1/cards/4111111111111111"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.valid").value(true))
                .andExpect(jsonPath("$.data.cardType").value("VISA"));
    }

    @Test
    void getCardDetails_Returns404_WhenNotFound() throws Exception {
        when(cardValidationService.getCardDetailsByCardNumber("0000000000000000"))
                .thenThrow(new ResourceNotFoundException("Card not found"));

        mockMvc.perform(get("/api/v1/cards/0000000000000000"))
                .andExpect(status().isNotFound());
    }

    @Test
    void validateCard_Returns200() throws Exception {
        when(cardValidationService.validateCard("4111111111111111")).thenReturn(sampleDTO);

        mockMvc.perform(post("/api/v1/cards/validate/4111111111111111"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.validationMessage").value("Card is valid"));
    }

    @Test
    void addCard_Returns201() throws Exception {
        CardDetail card = CardDetail.builder()
                .cardNumber("4111111111111111").cardHolderName("John Doe")
                .expiryMonth(12).expiryYear(2028).userId(1L).build();
        when(cardValidationService.addCard(any())).thenReturn(sampleDTO);

        mockMvc.perform(post("/api/v1/cards")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(card)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true));
    }
}
