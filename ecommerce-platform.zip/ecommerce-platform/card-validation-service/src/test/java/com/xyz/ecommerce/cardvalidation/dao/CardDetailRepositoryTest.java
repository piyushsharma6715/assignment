package com.xyz.ecommerce.cardvalidation.dao;

import com.xyz.ecommerce.cardvalidation.model.CardDetail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CardDetailRepositoryTest {

    @Mock
    private CardDetailRepository cardDetailRepository;

    private CardDetail sampleCard;

    @BeforeEach
    void setUp() {
        sampleCard = CardDetail.builder()
                .id(1L).cardNumber("4111111111111111")
                .cardHolderName("John Doe").expiryMonth(12).expiryYear(2028)
                .cardType("VISA").userId(1L).valid(true).build();
    }

    @Test
    void findByCardNumber_ReturnsCard_WhenExists() {
        when(cardDetailRepository.findByCardNumber("4111111111111111"))
                .thenReturn(Optional.of(sampleCard));

        Optional<CardDetail> result = cardDetailRepository.findByCardNumber("4111111111111111");

        assertTrue(result.isPresent());
        assertEquals("VISA", result.get().getCardType());
        verify(cardDetailRepository).findByCardNumber("4111111111111111");
    }

    @Test
    void findByCardNumber_ReturnsEmpty_WhenNotFound() {
        when(cardDetailRepository.findByCardNumber("0000000000000000"))
                .thenReturn(Optional.empty());

        Optional<CardDetail> result = cardDetailRepository.findByCardNumber("0000000000000000");

        assertFalse(result.isPresent());
    }

    @Test
    void findByUserId_ReturnsCard() {
        when(cardDetailRepository.findByUserId(1L)).thenReturn(Optional.of(sampleCard));

        Optional<CardDetail> result = cardDetailRepository.findByUserId(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getUserId());
    }

    @Test
    void save_PersistsCard() {
        when(cardDetailRepository.save(sampleCard)).thenReturn(sampleCard);

        CardDetail saved = cardDetailRepository.save(sampleCard);

        assertNotNull(saved);
        assertEquals("4111111111111111", saved.getCardNumber());
    }
}
