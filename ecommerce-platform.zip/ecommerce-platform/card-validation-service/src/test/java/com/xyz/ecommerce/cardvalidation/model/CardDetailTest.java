package com.xyz.ecommerce.cardvalidation.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CardDetailTest {

    @Test
    void testCardDetailBuilder() {
        CardDetail card = CardDetail.builder()
                .id(1L)
                .cardNumber("4111111111111111")
                .cardHolderName("John Doe")
                .expiryMonth(12)
                .expiryYear(2028)
                .cardType("VISA")
                .userId(10L)
                .valid(true)
                .build();

        assertEquals(1L, card.getId());
        assertEquals("4111111111111111", card.getCardNumber());
        assertEquals("John Doe", card.getCardHolderName());
        assertEquals(12, card.getExpiryMonth());
        assertEquals(2028, card.getExpiryYear());
        assertEquals("VISA", card.getCardType());
        assertEquals(10L, card.getUserId());
        assertTrue(card.isValid());
    }

    @Test
    void testCardValidationDTO_fromEntity_MasksNumber() {
        CardDetail card = CardDetail.builder()
                .id(1L).cardNumber("4111111111111111")
                .cardHolderName("Jane Doe").cardType("VISA").valid(true).build();

        CardValidationDTO dto = CardValidationDTO.fromEntity(card);

        assertEquals("**** **** **** 1111", dto.getMaskedCardNumber());
        assertTrue(dto.isValid());
        assertEquals("Card is valid", dto.getValidationMessage());
    }

    @Test
    void testCardValidationDTO_fromEntity_InvalidCard() {
        CardDetail card = CardDetail.builder()
                .id(2L).cardNumber("5500005555555559")
                .cardHolderName("Bob").cardType("MASTERCARD").valid(false).build();

        CardValidationDTO dto = CardValidationDTO.fromEntity(card);

        assertFalse(dto.isValid());
        assertEquals("Card is invalid", dto.getValidationMessage());
        assertTrue(dto.getMaskedCardNumber().startsWith("****"));
    }

    @Test
    void testCardValidationDTO_Builder() {
        CardValidationDTO dto = CardValidationDTO.builder()
                .id(1L).maskedCardNumber("**** **** **** 1234")
                .cardHolderName("Test User").cardType("AMEX")
                .valid(true).validationMessage("Valid")
                .build();
        assertNotNull(dto);
        assertEquals("AMEX", dto.getCardType());
    }
}
