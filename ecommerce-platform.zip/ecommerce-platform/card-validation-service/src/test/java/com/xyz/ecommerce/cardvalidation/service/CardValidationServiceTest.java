package com.xyz.ecommerce.cardvalidation.service;

import com.xyz.ecommerce.cardvalidation.dao.CardDetailRepository;
import com.xyz.ecommerce.cardvalidation.model.CardDetail;
import com.xyz.ecommerce.cardvalidation.model.CardValidationDTO;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * CardValidationService tests demonstrating:
 * - Mockito for mocking DAO layer
 * - Java Reflection to test 3 private methods:
 *     1. validateLuhn(String)
 *     2. isExpired(CardDetail)
 *     3. detectCardType(String)
 */
@ExtendWith(MockitoExtension.class)
class CardValidationServiceTest {

    @Mock
    private CardDetailRepository cardDetailRepository;

    @Mock
    private AppLogger appLogger;

    @InjectMocks
    private CardValidationService cardValidationService;

    private CardDetail validCard;

    @BeforeEach
    void setUp() {
        validCard = CardDetail.builder()
                .id(1L)
                .cardNumber("4111111111111111") // valid Luhn VISA test number
                .cardHolderName("John Doe")
                .expiryMonth(12)
                .expiryYear(2030)
                .cardType("VISA")
                .userId(1L)
                .valid(true)
                .build();
    }

    // ─── Service-level tests ─────────────────────────────────────────────────────

    @Test
    void getCardDetailsByCardNumber_ReturnsDTO_WhenFound() {
        when(cardDetailRepository.findByCardNumber("4111111111111111"))
                .thenReturn(Optional.of(validCard));

        CardValidationDTO result = cardValidationService.getCardDetailsByCardNumber("4111111111111111");

        assertNotNull(result);
        assertTrue(result.getMaskedCardNumber().endsWith("1111"));
        verify(cardDetailRepository).findByCardNumber("4111111111111111");
    }

    @Test
    void getCardDetailsByCardNumber_Throws_WhenNotFound() {
        when(cardDetailRepository.findByCardNumber("0000000000000000"))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> cardValidationService.getCardDetailsByCardNumber("0000000000000000"));
    }

    @Test
    void validateCard_MarksValid_ForGoodCard() {
        when(cardDetailRepository.findByCardNumber("4111111111111111"))
                .thenReturn(Optional.of(validCard));
        when(cardDetailRepository.save(any())).thenReturn(validCard);

        CardValidationDTO result = cardValidationService.validateCard("4111111111111111");

        assertNotNull(result);
        verify(cardDetailRepository).save(any());
    }

    @Test
    void addCard_SavesAndReturnsDTO() {
        when(cardDetailRepository.save(any())).thenReturn(validCard);

        CardValidationDTO result = cardValidationService.addCard(validCard);

        assertNotNull(result);
        verify(cardDetailRepository).save(any());
    }

    // ─── Reflection Test 1: validateLuhn ─────────────────────────────────────────

    @Test
    void reflectionTest_validateLuhn_ValidNumber_ReturnsTrue() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("validateLuhn", String.class);
        method.setAccessible(true);

        // 4111111111111111 is the canonical Luhn-valid VISA test number
        boolean result = (boolean) method.invoke(cardValidationService, "4111111111111111");

        assertTrue(result, "4111111111111111 should pass Luhn check");
    }

    @Test
    void reflectionTest_validateLuhn_InvalidNumber_ReturnsFalse() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("validateLuhn", String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(cardValidationService, "1234567890123456");

        assertFalse(result, "Random number should fail Luhn check");
    }

    @Test
    void reflectionTest_validateLuhn_NullInput_ReturnsFalse() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("validateLuhn", String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(cardValidationService, (Object) null);

        assertFalse(result);
    }

    @Test
    void reflectionTest_validateLuhn_EmptyString_ReturnsFalse() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("validateLuhn", String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(cardValidationService, "");

        assertFalse(result);
    }

    // ─── Reflection Test 2: isExpired ────────────────────────────────────────────

    @Test
    void reflectionTest_isExpired_FutureCard_ReturnsFalse() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("isExpired", CardDetail.class);
        method.setAccessible(true);

        CardDetail futureCard = CardDetail.builder()
                .expiryMonth(12).expiryYear(2030).build();

        boolean result = (boolean) method.invoke(cardValidationService, futureCard);

        assertFalse(result, "Card expiring in 2030 should NOT be expired");
    }

    @Test
    void reflectionTest_isExpired_PastCard_ReturnsTrue() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("isExpired", CardDetail.class);
        method.setAccessible(true);

        CardDetail expiredCard = CardDetail.builder()
                .expiryMonth(1).expiryYear(2020).build();

        boolean result = (boolean) method.invoke(cardValidationService, expiredCard);

        assertTrue(result, "Card expired in 2020 should be flagged as expired");
    }

    // ─── Reflection Test 3: detectCardType ───────────────────────────────────────

    @Test
    void reflectionTest_detectCardType_Visa_StartsWithFour() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("detectCardType", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(cardValidationService, "4111111111111111");

        assertEquals("VISA", result);
    }

    @Test
    void reflectionTest_detectCardType_Mastercard_StartsWithFive() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("detectCardType", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(cardValidationService, "5500005555555559");

        assertEquals("MASTERCARD", result);
    }

    @Test
    void reflectionTest_detectCardType_Amex_StartsWithThree() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("detectCardType", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(cardValidationService, "371449635398431");

        assertEquals("AMEX", result);
    }

    @Test
    void reflectionTest_detectCardType_Unknown_ReturnsUnknown() throws Exception {
        Method method = CardValidationService.class.getDeclaredMethod("detectCardType", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(cardValidationService, "6011000990139424");

        assertEquals("UNKNOWN", result);
    }
}
