package com.xyz.ecommerce.userservice.config;

import com.xyz.ecommerce.common.dto.ApiResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign Client to call Card Validation microservice.
 * Demonstrates inter-service communication using Feign Client.
 */
@FeignClient(name = "card-validation-service", url = "${card.validation.service.url}")
public interface CardValidationFeignClient {

    @GetMapping("/api/v1/cards/{cardNumber}")
    ApiResponse<Object> getCardDetails(@PathVariable("cardNumber") String cardNumber);

    @GetMapping("/api/v1/cards/validate/{cardNumber}")
    ApiResponse<Object> validateCard(@PathVariable("cardNumber") String cardNumber);
}
