package com.xyz.ecommerce.userservice.service;

import com.xyz.ecommerce.common.exception.BadRequestException;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.userservice.dao.UserRepository;
import com.xyz.ecommerce.userservice.model.User;
import com.xyz.ecommerce.userservice.model.UserDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * User Service - demonstrates:
 * - MVC pattern (Service layer)
 * - IoC/DI via @RequiredArgsConstructor
 * - Transaction management via @Transactional
 * - @Value for configuration management
 * - AppLogger from common-library (reusability)
 */
@Service
@RequiredArgsConstructor
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final AppLogger appLogger;

    // Configuration management - demonstrates @Value annotation
    @Value("${user.service.max-users:1000}")
    private int maxUsers;

    @Value("${user.service.name:User-Service}")
    private String serviceName;

    public UserDTO createUser(User user) {
        appLogger.info(UserService.class, "Creating user with email: {}", user.getEmail());

        if (userRepository.existsByEmail(user.getEmail())) {
            throw new BadRequestException("User already exists with email: " + user.getEmail());
        }

        // In production: encode password before saving
        User savedUser = userRepository.save(user);
        appLogger.info(UserService.class, "User created successfully with ID: {}", savedUser.getId());
        return UserDTO.fromEntity(savedUser);
    }

    @Transactional(readOnly = true)
    public UserDTO getUserById(Long id) {
        appLogger.info(UserService.class, "Fetching user with ID: {}", id);
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + id));
        return UserDTO.fromEntity(user);
    }

    @Transactional(readOnly = true)
    public UserDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        return UserDTO.fromEntity(user);
    }

    @Transactional(readOnly = true)
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll()
                .stream()
                .map(UserDTO::fromEntity)
                .collect(Collectors.toList());
    }

    public UserDTO updateUser(Long id, User updatedUser) {
        appLogger.info(UserService.class, "Updating user with ID: {}", id);
        User existing = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + id));

        existing.setFirstName(updatedUser.getFirstName());
        existing.setLastName(updatedUser.getLastName());
        existing.setPhone(updatedUser.getPhone());

        User saved = userRepository.save(existing);
        return UserDTO.fromEntity(saved);
    }

    public void deleteUser(Long id) {
        appLogger.info(UserService.class, "Deleting user with ID: {}", id);
        if (!userRepository.existsById(id)) {
            throw new ResourceNotFoundException("User not found with ID: " + id);
        }
        userRepository.deleteById(id);
    }

    /**
     * Private method - demonstrates Java Reflection in tests.
     */
    private boolean isValidEmail(String email) {
        return email != null && email.contains("@") && email.contains(".");
    }

    /**
     * Exposed for testing private method via reflection.
     */
    public String getServiceName() {
        return serviceName;
    }
}
