package com.xyz.ecommerce.userservice.service;

import com.xyz.ecommerce.common.dto.ApiResponse;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.userservice.config.CardValidationFeignClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * Demonstrates both RestTemplate and Feign Client for inter-service communication.
 * Purpose: understand the difference between RestTemplate and FeignClient.
 */
@Service
@RequiredArgsConstructor
public class CardIntegrationService {

    private final RestTemplate restTemplate;
    private final CardValidationFeignClient cardValidationFeignClient;
    private final AppLogger appLogger;

    @Value("${card.validation.service.url}")
    private String cardValidationServiceUrl;

    /**
     * Calls Card Validation service using RestTemplate.
     */
    public Object getCardDetailsViaRestTemplate(String cardNumber) {
        appLogger.info(CardIntegrationService.class, "Calling card validation via RestTemplate for card: {}",
                cardNumber.substring(Math.max(0, cardNumber.length() - 4)));

        String url = cardValidationServiceUrl + "/api/v1/cards/" + cardNumber;
        return restTemplate.getForObject(url, ApiResponse.class);
    }

    /**
     * Calls Card Validation service using Feign Client.
     */
    public ApiResponse<Object> getCardDetailsViaFeignClient(String cardNumber) {
        appLogger.info(CardIntegrationService.class, "Calling card validation via Feign Client");
        return cardValidationFeignClient.getCardDetails(cardNumber);
    }

    /**
     * Validate card before payment - uses Feign.
     */
    public ApiResponse<Object> validateCardViaFeignClient(String cardNumber) {
        appLogger.info(CardIntegrationService.class, "Validating card via Feign Client");
        return cardValidationFeignClient.validateCard(cardNumber);
    }
}
