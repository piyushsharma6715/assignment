package com.xyz.ecommerce.userservice.dao;

import com.xyz.ecommerce.userservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * User Repository - demonstrates DAO/Repository design pattern.
 * Separates data access logic from business logic.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.active = true AND u.email = :email")
    Optional<User> findActiveUserByEmail(String email);
}
