package com.xyz.ecommerce.userservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xyz.ecommerce.common.dto.ApiResponse;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.userservice.model.User;
import com.xyz.ecommerce.userservice.model.UserDTO;
import com.xyz.ecommerce.userservice.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Controller layer tests using MockMvc - no server starts.
 * Demonstrates testing REST endpoints with Mockito-mocked service.
 */
@WebMvcTest(controllers = UserController.class,
        excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE,
                classes = com.xyz.ecommerce.userservice.config.GlobalExceptionHandler.class))
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    private User sampleUser;
    private UserDTO sampleUserDTO;

    @BeforeEach
    void setUp() {
        sampleUser = User.builder()
                .id(1L).firstName("John").lastName("Doe")
                .email("john@example.com").password("password123").phone("555-1234")
                .build();

        sampleUserDTO = UserDTO.builder()
                .id(1L).firstName("John").lastName("Doe")
                .email("john@example.com").phone("555-1234").active(true)
                .build();
    }

    @Test
    void createUser_Returns201_WhenValid() throws Exception {
        when(userService.createUser(any(User.class))).thenReturn(sampleUserDTO);

        mockMvc.perform(post("/api/v1/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleUser)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.email").value("john@example.com"));
    }

    @Test
    void getUserById_Returns200_WhenFound() throws Exception {
        when(userService.getUserById(1L)).thenReturn(sampleUserDTO);

        mockMvc.perform(get("/api/v1/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value(1));
    }

    @Test
    void getUserById_Returns404_WhenNotFound() throws Exception {
        when(userService.getUserById(99L))
                .thenThrow(new ResourceNotFoundException("User not found with ID: 99"));

        mockMvc.perform(get("/api/v1/users/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getAllUsers_Returns200_WithList() throws Exception {
        when(userService.getAllUsers()).thenReturn(List.of(sampleUserDTO));

        mockMvc.perform(get("/api/v1/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.length()").value(1));
    }

    @Test
    void updateUser_Returns200_WhenValid() throws Exception {
        when(userService.updateUser(eq(1L), any(User.class))).thenReturn(sampleUserDTO);

        mockMvc.perform(put("/api/v1/users/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void deleteUser_Returns200_WhenFound() throws Exception {
        doNothing().when(userService).deleteUser(1L);

        mockMvc.perform(delete("/api/v1/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void getUserByEmail_Returns200_WhenFound() throws Exception {
        when(userService.getUserByEmail("john@example.com")).thenReturn(sampleUserDTO);

        mockMvc.perform(get("/api/v1/users/email/john@example.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.email").value("john@example.com"));
    }
}
