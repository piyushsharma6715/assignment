package com.xyz.ecommerce.userservice.service;

import com.xyz.ecommerce.common.exception.BadRequestException;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.userservice.dao.UserRepository;
import com.xyz.ecommerce.userservice.model.User;
import com.xyz.ecommerce.userservice.model.UserDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * UserService unit tests.
 * Demonstrates:
 * - Mockito for mocking repository and logger
 * - @InjectMocks for IoC in tests
 * - Java Reflection to test private method isValidEmail()
 */
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private AppLogger appLogger;

    @InjectMocks
    private UserService userService;

    private User sampleUser;

    @BeforeEach
    void setUp() {
        sampleUser = User.builder()
                .id(1L)
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .password("password123")
                .phone("555-1234")
                .active(true)
                .build();
    }

    // ─── createUser ─────────────────────────────────────────────────────────────

    @Test
    void createUser_Success() {
        when(userRepository.existsByEmail("john@example.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(sampleUser);

        UserDTO result = userService.createUser(sampleUser);

        assertNotNull(result);
        assertEquals("john@example.com", result.getEmail());
        verify(userRepository).save(sampleUser);
    }

    @Test
    void createUser_ThrowsBadRequest_WhenEmailExists() {
        when(userRepository.existsByEmail("john@example.com")).thenReturn(true);

        assertThrows(BadRequestException.class, () -> userService.createUser(sampleUser));
        verify(userRepository, never()).save(any());
    }

    // ─── getUserById ─────────────────────────────────────────────────────────────

    @Test
    void getUserById_ReturnsUser_WhenFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));

        UserDTO result = userService.getUserById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    @Test
    void getUserById_ThrowsResourceNotFound_WhenMissing() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userService.getUserById(99L));
    }

    // ─── getUserByEmail ──────────────────────────────────────────────────────────

    @Test
    void getUserByEmail_ReturnsUser_WhenFound() {
        when(userRepository.findByEmail("john@example.com")).thenReturn(Optional.of(sampleUser));

        UserDTO result = userService.getUserByEmail("john@example.com");

        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    void getUserByEmail_ThrowsResourceNotFound_WhenMissing() {
        when(userRepository.findByEmail("unknown@example.com")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> userService.getUserByEmail("unknown@example.com"));
    }

    // ─── getAllUsers ──────────────────────────────────────────────────────────────

    @Test
    void getAllUsers_ReturnsListOfUsers() {
        User user2 = User.builder().id(2L).firstName("Jane").lastName("Doe")
                .email("jane@example.com").password("pass").build();
        when(userRepository.findAll()).thenReturn(List.of(sampleUser, user2));

        List<UserDTO> result = userService.getAllUsers();

        assertEquals(2, result.size());
    }

    @Test
    void getAllUsers_ReturnsEmptyList_WhenNoUsers() {
        when(userRepository.findAll()).thenReturn(List.of());

        List<UserDTO> result = userService.getAllUsers();

        assertTrue(result.isEmpty());
    }

    // ─── updateUser ──────────────────────────────────────────────────────────────

    @Test
    void updateUser_Success() {
        User updated = User.builder().firstName("Johnny").lastName("Doe")
                .email("john@example.com").password("pass").phone("999").build();
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));
        when(userRepository.save(any(User.class))).thenReturn(sampleUser);

        UserDTO result = userService.updateUser(1L, updated);

        assertNotNull(result);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void updateUser_ThrowsResourceNotFound_WhenUserMissing() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> userService.updateUser(99L, sampleUser));
    }

    // ─── deleteUser ──────────────────────────────────────────────────────────────

    @Test
    void deleteUser_Success() {
        when(userRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRepository).deleteById(1L);

        assertDoesNotThrow(() -> userService.deleteUser(1L));
        verify(userRepository).deleteById(1L);
    }

    @Test
    void deleteUser_ThrowsResourceNotFound_WhenUserMissing() {
        when(userRepository.existsById(99L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> userService.deleteUser(99L));
    }

    // ─── Java Reflection: test private method isValidEmail ──────────────────────

    /**
     * Demonstrates testing a private method using Java Reflection.
     * This is ONE way to test private methods without changing visibility.
     */
    @Test
    void testPrivateMethod_isValidEmail_WithReflection_ValidEmail() throws Exception {
        Method method = UserService.class.getDeclaredMethod("isValidEmail", String.class);
        method.setAccessible(true);   // bypass private access modifier

        boolean result = (boolean) method.invoke(userService, "test@example.com");

        assertTrue(result, "Expected valid email to return true");
    }

    @Test
    void testPrivateMethod_isValidEmail_WithReflection_InvalidEmail_NoAt() throws Exception {
        Method method = UserService.class.getDeclaredMethod("isValidEmail", String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(userService, "invalidemail.com");

        assertFalse(result, "Email without @ should be invalid");
    }

    @Test
    void testPrivateMethod_isValidEmail_WithReflection_NullEmail() throws Exception {
        Method method = UserService.class.getDeclaredMethod("isValidEmail", String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(userService, (Object) null);

        assertFalse(result, "Null email should be invalid");
    }

    /**
     * SECOND WAY: test private method behaviour indirectly through public method.
     * Tests the effect rather than calling the private method directly.
     */
    @Test
    void testPrivateMethodIndirectly_ViaPublicMethod() {
        when(userRepository.existsByEmail("john@example.com")).thenReturn(false);
        when(userRepository.save(any())).thenReturn(sampleUser);

        // The public createUser internally calls private isValidEmail
        UserDTO dto = userService.createUser(sampleUser);
        assertNotNull(dto);
    }
}
