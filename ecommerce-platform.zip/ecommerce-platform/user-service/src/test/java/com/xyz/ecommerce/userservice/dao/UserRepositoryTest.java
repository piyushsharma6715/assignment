package com.xyz.ecommerce.userservice.dao;

import com.xyz.ecommerce.userservice.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * DAO layer tests - uses Mockito to mock repository behaviour.
 * Demonstrates Mockito mocking of Spring Data repositories.
 */
@ExtendWith(MockitoExtension.class)
class UserRepositoryTest {

    @Mock
    private UserRepository userRepository;

    private User sampleUser;

    @BeforeEach
    void setUp() {
        sampleUser = User.builder()
                .id(1L)
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .password("password123")
                .active(true)
                .build();
    }

    @Test
    void testFindByEmail_ReturnsUser() {
        when(userRepository.findByEmail("john@example.com")).thenReturn(Optional.of(sampleUser));

        Optional<User> result = userRepository.findByEmail("john@example.com");

        assertTrue(result.isPresent());
        assertEquals("john@example.com", result.get().getEmail());
        verify(userRepository, times(1)).findByEmail("john@example.com");
    }

    @Test
    void testFindByEmail_ReturnsEmpty_WhenNotFound() {
        when(userRepository.findByEmail("unknown@example.com")).thenReturn(Optional.empty());

        Optional<User> result = userRepository.findByEmail("unknown@example.com");

        assertFalse(result.isPresent());
    }

    @Test
    void testExistsByEmail_ReturnsTrue() {
        when(userRepository.existsByEmail("john@example.com")).thenReturn(true);

        boolean exists = userRepository.existsByEmail("john@example.com");

        assertTrue(exists);
    }

    @Test
    void testExistsByEmail_ReturnsFalse_WhenNotFound() {
        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);

        boolean exists = userRepository.existsByEmail("new@example.com");

        assertFalse(exists);
    }

    @Test
    void testSave_PersistsUser() {
        when(userRepository.save(sampleUser)).thenReturn(sampleUser);

        User saved = userRepository.save(sampleUser);

        assertNotNull(saved);
        assertEquals(1L, saved.getId());
        verify(userRepository).save(sampleUser);
    }

    @Test
    void testFindAll_ReturnsUserList() {
        User user2 = User.builder().id(2L).firstName("Jane").lastName("Doe")
                .email("jane@example.com").password("pass").build();
        when(userRepository.findAll()).thenReturn(List.of(sampleUser, user2));

        List<User> users = userRepository.findAll();

        assertEquals(2, users.size());
    }

    @Test
    void testDeleteById_CallsRepository() {
        doNothing().when(userRepository).deleteById(1L);

        userRepository.deleteById(1L);

        verify(userRepository, times(1)).deleteById(1L);
    }

    @Test
    void testFindById_ReturnsUser() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));

        Optional<User> result = userRepository.findById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
    }
}
