package com.xyz.ecommerce.userservice.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    @Test
    void testUserBuilderCreatesUserCorrectly() {
        User user = User.builder()
                .id(1L)
                .firstName("John")
                .lastName("Doe")
                .email("john.doe@example.com")
                .password("secret")
                .phone("1234567890")
                .active(true)
                .build();

        assertEquals(1L, user.getId());
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
        assertEquals("john.doe@example.com", user.getEmail());
        assertEquals("secret", user.getPassword());
        assertEquals("1234567890", user.getPhone());
        assertTrue(user.isActive());
    }

    @Test
    void testUserDefaultActiveIsTrue() {
        User user = User.builder()
                .firstName("Jane")
                .lastName("Doe")
                .email("jane@example.com")
                .password("pass")
                .build();
        assertTrue(user.isActive());
    }

    @Test
    void testUserSettersAndGetters() {
        User user = new User();
        user.setFirstName("Alice");
        user.setEmail("alice@example.com");
        assertEquals("Alice", user.getFirstName());
        assertEquals("alice@example.com", user.getEmail());
    }

    @Test
    void testUserAddressesInitializedEmpty() {
        User user = User.builder()
                .firstName("Bob").lastName("Smith")
                .email("bob@example.com").password("pass").build();
        assertNotNull(user.getAddresses());
        assertTrue(user.getAddresses().isEmpty());
    }

    @Test
    void testUserDTOFromEntity() {
        User user = User.builder()
                .id(5L).firstName("Tom").lastName("Jones")
                .email("tom@example.com").phone("999").active(true).build();

        UserDTO dto = UserDTO.fromEntity(user);

        assertEquals(5L, dto.getId());
        assertEquals("Tom", dto.getFirstName());
        assertEquals("Jones", dto.getLastName());
        assertEquals("tom@example.com", dto.getEmail());
        assertEquals("999", dto.getPhone());
        assertTrue(dto.isActive());
    }

    @Test
    void testUserDTOBuilder() {
        UserDTO dto = UserDTO.builder()
                .id(1L).firstName("Alice").lastName("Wonder")
                .email("alice@wonder.com").phone("123").active(true)
                .build();
        assertNotNull(dto);
        assertEquals("Alice", dto.getFirstName());
    }
}
