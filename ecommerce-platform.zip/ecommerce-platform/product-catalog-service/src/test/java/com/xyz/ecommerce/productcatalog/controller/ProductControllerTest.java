package com.xyz.ecommerce.productcatalog.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.productcatalog.model.Product;
import com.xyz.ecommerce.productcatalog.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ProductService productService;

    private Product sampleProduct;

    @BeforeEach
    void setUp() {
        sampleProduct = Product.builder()
                .id(1L).name("Laptop").description("Gaming Laptop")
                .price(new BigDecimal("999.99")).stockQuantity(10)
                .category("Electronics").available(true).build();
    }

    @Test
    void createProduct_Returns201() throws Exception {
        when(productService.createProduct(any())).thenReturn(sampleProduct);
        mockMvc.perform(post("/api/v1/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleProduct)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.name").value("Laptop"));
    }

    @Test
    void getProductById_Returns200() throws Exception {
        when(productService.getProductById(1L)).thenReturn(sampleProduct);
        mockMvc.perform(get("/api/v1/products/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.id").value(1));
    }

    @Test
    void getProductById_Returns404_WhenNotFound() throws Exception {
        when(productService.getProductById(99L)).thenThrow(new ResourceNotFoundException("Not found"));
        mockMvc.perform(get("/api/v1/products/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getAllProducts_Returns200() throws Exception {
        when(productService.getAllProducts()).thenReturn(List.of(sampleProduct));
        mockMvc.perform(get("/api/v1/products"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.length()").value(1));
    }

    @Test
    void searchProducts_Returns200() throws Exception {
        when(productService.searchByName("lap")).thenReturn(List.of(sampleProduct));
        mockMvc.perform(get("/api/v1/products/search").param("name", "lap"))
                .andExpect(status().isOk());
    }

    @Test
    void updateProduct_Returns200() throws Exception {
        when(productService.updateProduct(eq(1L), any())).thenReturn(sampleProduct);
        mockMvc.perform(put("/api/v1/products/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sampleProduct)))
                .andExpect(status().isOk());
    }

    @Test
    void deleteProduct_Returns200() throws Exception {
        doNothing().when(productService).deleteProduct(1L);
        mockMvc.perform(delete("/api/v1/products/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }
}
