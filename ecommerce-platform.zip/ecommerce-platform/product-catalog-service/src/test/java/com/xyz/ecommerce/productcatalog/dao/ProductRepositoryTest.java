package com.xyz.ecommerce.productcatalog.dao;

import com.xyz.ecommerce.productcatalog.model.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductRepositoryTest {

    @Mock
    private ProductRepository productRepository;

    private Product sampleProduct;

    @BeforeEach
    void setUp() {
        sampleProduct = Product.builder()
                .id(1L).name("Laptop").price(new BigDecimal("999.99"))
                .stockQuantity(10).category("Electronics").available(true).build();
    }

    @Test
    void findByCategory_ReturnsProducts() {
        when(productRepository.findByCategory("Electronics")).thenReturn(List.of(sampleProduct));
        List<Product> result = productRepository.findByCategory("Electronics");
        assertEquals(1, result.size());
    }

    @Test
    void findByAvailableTrue_ReturnsAvailableProducts() {
        when(productRepository.findByAvailableTrue()).thenReturn(List.of(sampleProduct));
        List<Product> result = productRepository.findByAvailableTrue();
        assertFalse(result.isEmpty());
        assertTrue(result.get(0).isAvailable());
    }

    @Test
    void findByNameContainingIgnoreCase_ReturnsMatches() {
        when(productRepository.findByNameContainingIgnoreCase("lap")).thenReturn(List.of(sampleProduct));
        List<Product> result = productRepository.findByNameContainingIgnoreCase("lap");
        assertEquals(1, result.size());
    }

    @Test
    void findById_ReturnsProduct() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        Optional<Product> result = productRepository.findById(1L);
        assertTrue(result.isPresent());
    }

    @Test
    void save_PersistsProduct() {
        when(productRepository.save(sampleProduct)).thenReturn(sampleProduct);
        Product saved = productRepository.save(sampleProduct);
        assertNotNull(saved);
        assertEquals("Laptop", saved.getName());
    }
}
