package com.xyz.ecommerce.productcatalog.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void testProductBuilder() {
        Product p = Product.builder()
                .id(1L).name("Laptop").description("Gaming Laptop")
                .price(new BigDecimal("999.99")).stockQuantity(10)
                .category("Electronics").available(true).build();

        assertEquals(1L, p.getId());
        assertEquals("Laptop", p.getName());
        assertEquals(new BigDecimal("999.99"), p.getPrice());
        assertTrue(p.isAvailable());
    }

    @Test
    void testProductDefaultAvailable_IsTrue() {
        Product p = Product.builder().name("Phone")
                .price(BigDecimal.TEN).build();
        assertTrue(p.isAvailable());
    }

    @Test
    void testProductSettersAndGetters() {
        Product p = new Product();
        p.setName("Tablet");
        p.setPrice(new BigDecimal("499.00"));
        p.setStockQuantity(5);
        assertEquals("Tablet", p.getName());
        assertEquals(5, p.getStockQuantity());
    }
}
