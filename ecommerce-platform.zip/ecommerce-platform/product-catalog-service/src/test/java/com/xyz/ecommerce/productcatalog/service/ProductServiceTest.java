package com.xyz.ecommerce.productcatalog.service;

import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.productcatalog.dao.ProductRepository;
import com.xyz.ecommerce.productcatalog.model.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private AppLogger appLogger;

    @InjectMocks
    private ProductService productService;

    private Product sampleProduct;

    @BeforeEach
    void setUp() {
        sampleProduct = Product.builder()
                .id(1L).name("Laptop").price(new BigDecimal("999.99"))
                .stockQuantity(10).category("Electronics").available(true).build();
    }

    @Test
    void createProduct_SavesAndReturns() {
        when(productRepository.save(any())).thenReturn(sampleProduct);
        Product result = productService.createProduct(sampleProduct);
        assertNotNull(result);
        assertEquals("Laptop", result.getName());
    }

    @Test
    void getProductById_ReturnsProduct_WhenFound() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        Product result = productService.getProductById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    void getProductById_Throws_WhenNotFound() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> productService.getProductById(99L));
    }

    @Test
    void getAllProducts_ReturnsList() {
        when(productRepository.findAll()).thenReturn(List.of(sampleProduct));
        assertEquals(1, productService.getAllProducts().size());
    }

    @Test
    void getAvailableProducts_ReturnsAvailable() {
        when(productRepository.findByAvailableTrue()).thenReturn(List.of(sampleProduct));
        assertEquals(1, productService.getAvailableProducts().size());
    }

    @Test
    void searchByName_ReturnsMatches() {
        when(productRepository.findByNameContainingIgnoreCase("lap")).thenReturn(List.of(sampleProduct));
        assertEquals(1, productService.searchByName("lap").size());
    }

    @Test
    void updateProduct_UpdatesAndReturns() {
        Product updated = Product.builder().name("Gaming Laptop").price(new BigDecimal("1299.99"))
                .stockQuantity(5).category("Electronics").available(true).build();
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        when(productRepository.save(any())).thenReturn(sampleProduct);
        Product result = productService.updateProduct(1L, updated);
        assertNotNull(result);
        verify(productRepository).save(any());
    }

    @Test
    void deleteProduct_DeletesWhenFound() {
        when(productRepository.existsById(1L)).thenReturn(true);
        doNothing().when(productRepository).deleteById(1L);
        assertDoesNotThrow(() -> productService.deleteProduct(1L));
        verify(productRepository).deleteById(1L);
    }

    @Test
    void deleteProduct_Throws_WhenNotFound() {
        when(productRepository.existsById(99L)).thenReturn(false);
        assertThrows(ResourceNotFoundException.class, () -> productService.deleteProduct(99L));
    }

    @Test
    void reduceStock_ReducesQuantity() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        when(productRepository.save(any())).thenReturn(sampleProduct);
        Product result = productService.reduceStock(1L, 3);
        assertNotNull(result);
        verify(productRepository).save(any());
    }

    @Test
    void reduceStock_Throws_WhenInsufficientStock() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        assertThrows(IllegalStateException.class, () -> productService.reduceStock(1L, 999));
    }
}
