package com.xyz.ecommerce.paymentservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.paymentservice.model.Payment;
import com.xyz.ecommerce.paymentservice.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PaymentController.class)
class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private PaymentService paymentService;

    private Payment samplePayment;

    @BeforeEach
    void setUp() {
        samplePayment = Payment.builder()
                .id(1L).orderId(10L).userId(5L)
                .amount(new BigDecimal("99.99"))
                .status(Payment.PaymentStatus.SUCCESS)
                .transactionId("txn-001").build();
    }

    @Test
    void processPayment_Returns201() throws Exception {
        when(paymentService.processPayment(any())).thenReturn(samplePayment);
        mockMvc.perform(post("/api/v1/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(samplePayment)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.transactionId").value("txn-001"));
    }

    @Test
    void getPaymentById_Returns200() throws Exception {
        when(paymentService.getPaymentById(1L)).thenReturn(samplePayment);
        mockMvc.perform(get("/api/v1/payments/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.id").value(1));
    }

    @Test
    void getPaymentById_Returns404_WhenNotFound() throws Exception {
        when(paymentService.getPaymentById(99L)).thenThrow(new ResourceNotFoundException("Not found"));
        mockMvc.perform(get("/api/v1/payments/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void getByOrder_Returns200() throws Exception {
        when(paymentService.getPaymentsByOrderId(10L)).thenReturn(List.of(samplePayment));
        mockMvc.perform(get("/api/v1/payments/order/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.length()").value(1));
    }

    @Test
    void getByUser_Returns200() throws Exception {
        when(paymentService.getPaymentsByUserId(5L)).thenReturn(List.of(samplePayment));
        mockMvc.perform(get("/api/v1/payments/user/5"))
                .andExpect(status().isOk());
    }

    @Test
    void refundPayment_Returns200() throws Exception {
        when(paymentService.refundPayment(1L)).thenReturn(samplePayment);
        mockMvc.perform(post("/api/v1/payments/1/refund"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }
}
