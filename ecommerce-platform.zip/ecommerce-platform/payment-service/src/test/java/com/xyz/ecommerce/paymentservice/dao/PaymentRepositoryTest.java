package com.xyz.ecommerce.paymentservice.dao;

import com.xyz.ecommerce.paymentservice.model.Payment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentRepositoryTest {

    @Mock
    private PaymentRepository paymentRepository;

    private Payment samplePayment;

    @BeforeEach
    void setUp() {
        samplePayment = Payment.builder()
                .id(1L).orderId(10L).userId(5L)
                .amount(new BigDecimal("99.99")).transactionId("txn-001")
                .status(Payment.PaymentStatus.SUCCESS).build();
    }

    @Test
    void findByOrderId_ReturnsPayments() {
        when(paymentRepository.findByOrderId(10L)).thenReturn(List.of(samplePayment));
        List<Payment> result = paymentRepository.findByOrderId(10L);
        assertEquals(1, result.size());
        assertEquals(10L, result.get(0).getOrderId());
    }

    @Test
    void findByUserId_ReturnsPayments() {
        when(paymentRepository.findByUserId(5L)).thenReturn(List.of(samplePayment));
        List<Payment> result = paymentRepository.findByUserId(5L);
        assertFalse(result.isEmpty());
    }

    @Test
    void findByTransactionId_ReturnsPayment() {
        when(paymentRepository.findByTransactionId("txn-001")).thenReturn(Optional.of(samplePayment));
        Optional<Payment> result = paymentRepository.findByTransactionId("txn-001");
        assertTrue(result.isPresent());
        assertEquals("txn-001", result.get().getTransactionId());
    }

    @Test
    void save_PersistsPayment() {
        when(paymentRepository.save(samplePayment)).thenReturn(samplePayment);
        Payment saved = paymentRepository.save(samplePayment);
        assertNotNull(saved);
        assertEquals(1L, saved.getId());
    }
}
