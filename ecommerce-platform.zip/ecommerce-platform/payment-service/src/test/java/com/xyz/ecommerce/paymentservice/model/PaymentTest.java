package com.xyz.ecommerce.paymentservice.model;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class PaymentTest {

    @Test
    void testPaymentBuilder() {
        Payment p = Payment.builder()
                .id(1L).orderId(10L).userId(5L)
                .amount(new BigDecimal("99.99")).cardNumber("4111111111111111")
                .transactionId("txn-abc123").build();

        assertEquals(1L, p.getId());
        assertEquals(10L, p.getOrderId());
        assertEquals(new BigDecimal("99.99"), p.getAmount());
        assertEquals(Payment.PaymentStatus.PENDING, p.getStatus());
        assertNotNull(p.getCreatedAt());
    }

    @Test
    void testPaymentDefaultStatus_IsPending() {
        Payment p = Payment.builder().orderId(1L).userId(1L).amount(BigDecimal.TEN).build();
        assertEquals(Payment.PaymentStatus.PENDING, p.getStatus());
    }

    @Test
    void testPaymentSetStatus() {
        Payment p = new Payment();
        p.setStatus(Payment.PaymentStatus.SUCCESS);
        assertEquals(Payment.PaymentStatus.SUCCESS, p.getStatus());
    }

    @Test
    void testPaymentStatusValues() {
        assertNotNull(Payment.PaymentStatus.valueOf("PENDING"));
        assertNotNull(Payment.PaymentStatus.valueOf("SUCCESS"));
        assertNotNull(Payment.PaymentStatus.valueOf("FAILED"));
        assertNotNull(Payment.PaymentStatus.valueOf("REFUNDED"));
    }
}
