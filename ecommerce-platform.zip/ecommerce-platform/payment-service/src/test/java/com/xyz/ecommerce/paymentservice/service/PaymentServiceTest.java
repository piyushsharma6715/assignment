package com.xyz.ecommerce.paymentservice.service;

import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.paymentservice.dao.PaymentRepository;
import com.xyz.ecommerce.paymentservice.model.Payment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private AppLogger appLogger;

    @InjectMocks
    private PaymentService paymentService;

    private Payment samplePayment;

    @BeforeEach
    void setUp() {
        samplePayment = Payment.builder()
                .id(1L).orderId(10L).userId(5L)
                .amount(new BigDecimal("99.99")).cardNumber("4111111111111111")
                .status(Payment.PaymentStatus.SUCCESS).transactionId("txn-001").build();
    }

    @Test
    void processPayment_ReturnsSuccessPayment_ForValidAmount() {
        when(paymentRepository.save(any())).thenReturn(samplePayment);
        Payment result = paymentService.processPayment(samplePayment);
        assertNotNull(result);
        verify(paymentRepository).save(any());
    }

    @Test
    void getPaymentById_ReturnsPayment_WhenFound() {
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(samplePayment));
        Payment result = paymentService.getPaymentById(1L);
        assertEquals(1L, result.getId());
    }

    @Test
    void getPaymentById_Throws_WhenNotFound() {
        when(paymentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> paymentService.getPaymentById(99L));
    }

    @Test
    void getPaymentsByOrderId_ReturnsList() {
        when(paymentRepository.findByOrderId(10L)).thenReturn(List.of(samplePayment));
        assertEquals(1, paymentService.getPaymentsByOrderId(10L).size());
    }

    @Test
    void getPaymentsByUserId_ReturnsList() {
        when(paymentRepository.findByUserId(5L)).thenReturn(List.of(samplePayment));
        assertEquals(1, paymentService.getPaymentsByUserId(5L).size());
    }

    @Test
    void refundPayment_RefundsSuccessfulPayment() {
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(samplePayment));
        when(paymentRepository.save(any())).thenReturn(samplePayment);
        Payment result = paymentService.refundPayment(1L);
        assertNotNull(result);
        verify(paymentRepository).save(any());
    }

    @Test
    void refundPayment_Throws_WhenNotSuccessStatus() {
        Payment failedPayment = Payment.builder().id(2L).orderId(10L).userId(5L)
                .amount(BigDecimal.TEN).status(Payment.PaymentStatus.FAILED).build();
        when(paymentRepository.findById(2L)).thenReturn(Optional.of(failedPayment));
        assertThrows(IllegalStateException.class, () -> paymentService.refundPayment(2L));
    }

    /** Reflection: test private processWithGateway method */
    @Test
    void reflectionTest_processWithGateway_ValidAmount_ReturnsTrue() throws Exception {
        Method method = PaymentService.class.getDeclaredMethod("processWithGateway", Payment.class);
        method.setAccessible(true);

        Payment payment = Payment.builder().amount(new BigDecimal("50.00")).build();
        boolean result = (boolean) method.invoke(paymentService, payment);

        assertTrue(result);
    }

    @Test
    void reflectionTest_processWithGateway_NullAmount_ReturnsFalse() throws Exception {
        Method method = PaymentService.class.getDeclaredMethod("processWithGateway", Payment.class);
        method.setAccessible(true);

        Payment payment = Payment.builder().build(); // null amount
        boolean result = (boolean) method.invoke(paymentService, payment);

        assertFalse(result);
    }
}
