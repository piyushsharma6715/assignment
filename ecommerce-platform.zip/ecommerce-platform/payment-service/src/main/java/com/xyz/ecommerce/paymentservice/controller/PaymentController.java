package com.xyz.ecommerce.paymentservice.controller;

import com.xyz.ecommerce.common.dto.ApiResponse;
import com.xyz.ecommerce.paymentservice.model.Payment;
import com.xyz.ecommerce.paymentservice.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<ApiResponse<Payment>> processPayment(@RequestBody Payment payment) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(paymentService.processPayment(payment), "Payment processed"));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Payment>> getPaymentById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.getPaymentById(id), "Payment retrieved"));
    }

    @GetMapping("/order/{orderId}")
    public ResponseEntity<ApiResponse<List<Payment>>> getByOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.getPaymentsByOrderId(orderId), "Payments retrieved"));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse<List<Payment>>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.getPaymentsByUserId(userId), "Payments retrieved"));
    }

    @PostMapping("/{id}/refund")
    public ResponseEntity<ApiResponse<Payment>> refundPayment(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(paymentService.refundPayment(id), "Payment refunded"));
    }
}
