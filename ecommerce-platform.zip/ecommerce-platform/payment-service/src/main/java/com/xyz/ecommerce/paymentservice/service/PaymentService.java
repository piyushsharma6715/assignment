package com.xyz.ecommerce.paymentservice.service;

import com.xyz.ecommerce.common.exception.ResourceNotFoundException;
import com.xyz.ecommerce.common.logger.AppLogger;
import com.xyz.ecommerce.paymentservice.dao.PaymentRepository;
import com.xyz.ecommerce.paymentservice.model.Payment;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final AppLogger appLogger;

    public Payment processPayment(Payment payment) {
        appLogger.info(PaymentService.class, "Processing payment for order: {}", payment.getOrderId());
        payment.setTransactionId(UUID.randomUUID().toString());
        boolean success = processWithGateway(payment);
        payment.setStatus(success ? Payment.PaymentStatus.SUCCESS : Payment.PaymentStatus.FAILED);
        Payment saved = paymentRepository.save(payment);
        appLogger.info(PaymentService.class, "Payment {} for order {}", saved.getStatus(), saved.getOrderId());
        return saved;
    }

    @Transactional(readOnly = true)
    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with ID: " + id));
    }

    @Transactional(readOnly = true)
    public List<Payment> getPaymentsByOrderId(Long orderId) {
        return paymentRepository.findByOrderId(orderId);
    }

    @Transactional(readOnly = true)
    public List<Payment> getPaymentsByUserId(Long userId) {
        return paymentRepository.findByUserId(userId);
    }

    public Payment refundPayment(Long paymentId) {
        Payment payment = getPaymentById(paymentId);
        if (payment.getStatus() != Payment.PaymentStatus.SUCCESS) {
            throw new IllegalStateException("Only successful payments can be refunded");
        }
        payment.setStatus(Payment.PaymentStatus.REFUNDED);
        return paymentRepository.save(payment);
    }

    /** Private method - simulates gateway call; testable via Reflection */
    private boolean processWithGateway(Payment payment) {
        return payment.getAmount() != null && payment.getAmount().doubleValue() > 0;
    }
}
